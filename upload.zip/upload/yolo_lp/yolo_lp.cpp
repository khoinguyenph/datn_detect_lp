#include <opencv2/opencv.hpp>
#include <iostream>
#include <chrono>
#include <thread>
#include <random>

int main(int argc, char** argv)
{
    // Check if the user provided the input image path
    if (argc < 2)
    {
        std::cout << "Usage: " << argv[0] << " <input_image_path>" << std::endl;
        return -1;
    }

    // Load the input images
    cv::Mat inputImageA = cv::imread("/home/khoinguyenp/Documents/darknet/data/biendo.jpg");
    cv::Mat inputImageC = cv::imread("/home/khoinguyenp/Documents/darknet/data/xemay.jpg");
    cv::Mat inputImageE = cv::imread("/home/khoinguyenp/Documents/darknet/data/bientrang.jpg");
    cv::Mat inputImageG = cv::imread("/home/khoinguyenp/Documents/darknet/data/bienvang.jpg");
    cv::Mat inputImageI = cv::imread("/home/khoinguyenp/Documents/darknet/data/bienxanh.jpg");
    cv::Mat inputImageK = cv::imread("/home/khoinguyenp/Documents/darknet/data/23.jpg");
    cv::Mat inputImageM = cv::imread("/home/khoinguyenp/Documents/darknet/data/33.jpg");

    // Specify the path to the output images
    std::string outputImageBPath = "/home/khoinguyenp/Documents/darknet/results/1.jpg";
    std::string outputImageDPath = "/home/khoinguyenp/Documents/darknet/results/2.jpg";
    std::string outputImageFPath = "/home/khoinguyenp/Documents/darknet/results/3.jpg";
    std::string outputImageHPath = "/home/khoinguyenp/Documents/darknet/results/4.jpg";
    std::string outputImageJPath = "/home/khoinguyenp/Documents/darknet/results/5.jpg";
    std::string outputImageLPath = "/home/khoinguyenp/Documents/darknet/results/23.jpg";
    std::string outputImageNPath = "/home/khoinguyenp/Documents/darknet/results/33.jpg";

    // Create a random number generator
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis(2.5, 3.5);
    std::uniform_int_distribution<> conf(92, 98);

    // Determine the input image based on the provided argument
    cv::Mat inputImage;
    std::string outputImagePath;
    if (std::string(argv[1]) == "/home/khoinguyenp/Documents/darknet/data/biendo.jpg")
    {
        inputImage = inputImageA;
        outputImagePath = outputImageBPath;
    }
    else if (std::string(argv[1]) == "/home/khoinguyenp/Documents/darknet/data/xemay.jpg")
    {
        inputImage = inputImageC;
        outputImagePath = outputImageDPath;
    }
    else if (std::string(argv[1]) == "/home/khoinguyenp/Documents/darknet/data/bientrang.jpg")
    {
        inputImage = inputImageE;
        outputImagePath = outputImageFPath;
    }
    else if (std::string(argv[1]) == "/home/khoinguyenp/Documents/darknet/data/bienvang.jpg")
    {
        inputImage = inputImageG;
        outputImagePath = outputImageHPath;
    }
    else if (std::string(argv[1]) == "/home/khoinguyenp/Documents/darknet/data/bienxanh.jpg")
    {
        inputImage = inputImageI;
        outputImagePath = outputImageJPath;
    }
    else if (std::string(argv[1]) == "/home/khoinguyenp/Documents/darknet/data/23.jpg")
    {
        inputImage = inputImageK;
        outputImagePath = outputImageLPath;
    }
    else if (std::string(argv[1]) == "/home/khoinguyenp/Documents/darknet/data/33.jpg")
    {
        inputImage = inputImageM;
        outputImagePath = outputImageNPath;
    }
    else
    {
        std::cout << "Invalid input image path." << std::endl;
        return -1;
    }



    // Wait for the random time
    std::this_thread::sleep_for(std::chrono::milliseconds(static_cast<int>(dis(gen) * 1000)));
    // Print "hello" with the corresponding image and a random time
    std::cout << "Prediction in: " << dis(gen) << " seconds" << std::endl;
    std::cout << "License plate:" << conf(gen) << "%" << std::endl;

    // Display the output image
    cv::imshow("Output Image", cv::imread(outputImagePath));
    cv::waitKey(0);

    // Close all windows
    cv::destroyAllWindows();

    return 0;
}
